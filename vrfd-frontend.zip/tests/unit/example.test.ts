import { test, assert, describe } from 'vitest'

describe('example test', () => {
  test('assert', () => {
    assert.equal(1, 1)
  })
})
